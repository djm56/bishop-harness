# Flight Recorder

Append-only audit journal. One row per state-sync and per completion event. Never edit or reorder existing rows; never rewrite the header. Timestamps are `YYYY-MM-DD HH:MM UTC` and are never invented. Escape every literal `|` in the Note as `\|`, and read each appended row back before reporting the sync done.

| Timestamp | Mission ID | Step | Agent | Event | Note |
|-----------|-----------|------|-------|-------|------|
