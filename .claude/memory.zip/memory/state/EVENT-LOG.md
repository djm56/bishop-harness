# Event Log

Append-only audit journal. One row per state-sync and per completion event. Never edit or reorder existing rows; never rewrite the header.

| Timestamp | Task ID | Step | Agent | Event | Note |
|-----------|---------|------|-------|-------|------|
