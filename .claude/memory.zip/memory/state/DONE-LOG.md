# Done Log

Append-only index of completed tasks. Never modify existing rows; never rewrite the header or separator. `Completed` is `YYYY-MM-DD HH:MM UTC`.

| Task ID          | Completed            | Outcome | Summary |
|------------------|----------------------|---------|---------|
