# Done Log

Append-only index of completed tasks. Never modify existing rows; never rewrite the header or separator.

| Task ID  | Completed        | Outcome | Summary |
|----------|------------------|---------|---------|
