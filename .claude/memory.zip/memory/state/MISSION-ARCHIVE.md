# Mission Archive

Append-only index of completed missions. Never modify existing rows; never rewrite the header or separator. `Completed` is `YYYY-MM-DD HH:MM UTC`.

| Mission ID       | Completed            | Outcome | Summary |
|------------------|----------------------|---------|---------|
