# Workspace — Scratch for In-Flight Work

Working space for whatever a mission needs while it is in flight: drafts, checklists, analysis, review write-ups, and `findings-scratch.md` — the running collection of IMPROVEMENT-NOTE findings that the closing learning pass consolidates.

- Any agent may create, update, edit, delete, and reorganise files here during a mission.
- The structure inside this folder is deliberately unconstrained.
- It is scratch, not record. Durable state lives in `.claude/memory/state/` and `.claude/memory/missions/mission-[id]/`.
- While the active mission is `in-progress` or `blocked`, everything here survives across sessions and counts as valid context on resume.
- At a confirmed new-mission start it is **archived, not deleted**: this file and `.gitkeep` stay, everything else moves into `archive-mission-[id]/`, and `findings-scratch.md` is recreated with a fresh header. A scratch file is sometimes the only copy of a deliverable that never shipped.
- Doctrine never lives here. How the system works belongs in agents, skills, and templates — a rule written into this folder is archived at the next mission init and goes quiet.

Full rules: `.claude/skills/mission-lifecycle/SKILL.md`.
