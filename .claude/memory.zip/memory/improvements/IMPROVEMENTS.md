# Improvements

Proposed changes to agent prompts, skills, or tools. Append-only. Status is human-controlled (proposed -> approved -> applied -> rejected). Approver and Date approved are set by a human only when status becomes approved.

<!-- Append new entries below this line -->
