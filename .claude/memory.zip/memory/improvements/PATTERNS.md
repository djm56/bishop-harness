# Patterns

Reusable code conventions, architecture decisions, and technical solutions discovered during tasks. Append-only.

<!-- Append new entries below this line -->
