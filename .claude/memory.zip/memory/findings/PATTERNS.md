# Patterns

Reusable solutions, architecture decisions, and technical approaches discovered during missions. Advisory and non-binding — `.claude/memory/reference/DIRECTIVES.md` wins on any conflict.

Append-only. New entries go below the marker at the bottom of this file, after every entry already there. The marker never moves and nothing already written is displaced.

<!-- Append new entries below this line -->
